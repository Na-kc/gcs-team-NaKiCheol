public class Sum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum = 0;
		for(int i = 0; i <=100; i++) {
			sum += i;
		}
		
		System.out.println("�հ� : " + sum);
	}

}