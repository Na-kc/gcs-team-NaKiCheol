public class ConvTemp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double Ctemp = 31.5f;
		double Ftemp = (Ctemp * 9/5) + 32;
		
		
		System.out.printf("���� : %5.1f\n", Ctemp);
		System.out.printf("ȭ�� : %5.1f\n", Ftemp);
	}

}
