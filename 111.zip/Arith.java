public class Arith {
	int Sum(int a, int b) {
		return a + b;
	}
	int Sub(int a, int b) {
		return a - b;
	}
	int Mut(int a, int b) {
		return a * b;
	}
	int Div(int a, int b) {
		return a / b;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
